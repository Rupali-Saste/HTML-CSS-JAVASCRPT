<?php

    $database = pg_connect("host=localhost dbname=db_doctor user=postgres password=1234");
    if (!$database)
    {
        die("Connection failed: ".pg_last_error());
    }

?>

